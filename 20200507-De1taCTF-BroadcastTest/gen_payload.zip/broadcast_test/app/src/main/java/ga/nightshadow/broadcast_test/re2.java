package ga.nightshadow.broadcast_test;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class re2 extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getBundleExtra("message");
        int id = intent.getIntExtra("id", 0);
        String command = bundle.getString("command");
        if (id == 0 || command == null || command.equals("getflag")) {
            Log.d("De1ta", "Failed in Receiver2! id:" + id);
            return;
        }
        try {
            Intent intent1 = new Intent();
            intent1.setAction("com.de1ta.receiver3");
            intent1.setClass(context, re3.class);
            intent1.putExtra("id", id);
            intent1.putExtra("message", bundle);
            context.sendBroadcast(intent1);
        } catch (Exception e) {
            Log.e("De1taDebug", "exception:", e);
            Log.d("De1ta", "Failed in Receiver2! id:" + id);
        }
    }
}
