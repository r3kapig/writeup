package ga.nightshadow.broadcast_test;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Base64;
import android.util.Log;

public class re3 extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getBundleExtra("message");
        Parcel test = Parcel.obtain();
        bundle.writeToParcel(test, 0);
        byte[] raww = test.marshall();
        String outputt = Base64.encodeToString(raww, 0);
        Log.i("final_deserialize", outputt);
        String command = bundle.getString("command");
        int id = intent.getIntExtra("id", 0);
        if (id == 0 || command == null || !command.equals("getflag")) {
            Log.d("De1ta", "Failed in Receiver3! id:" + id);
            return;
        }
        Log.d("De1ta", "Congratulations! id:" + id);
    }
}
